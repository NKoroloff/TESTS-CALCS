document.addEventListener("DOMContentLoaded", () => {
    init();
});

function init() {
    initElements();
    addListeners();
}
